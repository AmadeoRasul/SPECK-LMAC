"""
Name: HuggingFace
URL: https://huggingface.co/
Features:
- Chat
"""
